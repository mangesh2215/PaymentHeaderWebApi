﻿using InterfaceLayer;
using ModelLayer;
using System;
using System.Collections.Generic;
using DataLayer;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace BusinessLayer
{
    public class PaymentDetailBL : IPaymentDetail
    {
        private readonly PaymentDetailContext _context;

        public PaymentDetailBL(PaymentDetailContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<PaymentDetailModel>> GetPaymentDetails() {
            return await _context.PaymentDetails.ToListAsync();
        }

        public async Task<object> SaveChangesAsync(PaymentDetailModel paymentDetail) {
            _context.Entry(paymentDetail).State = EntityState.Modified;
            return await _context.SaveChangesAsync();
        }

        public async Task<PaymentDetailModel> GetPaymentDetailByID(int id) {
            return await _context.PaymentDetails.FindAsync(id);
        }

        public async Task<Int32> PostPaymentDetail(PaymentDetailModel paymentDetail) {
            _context.PaymentDetails.Add(paymentDetail);
            return await _context.SaveChangesAsync();
        }

        public async Task<object> Remove(PaymentDetailModel paymentDetail) {
            _context.PaymentDetails.Remove(paymentDetail);
            return await _context.SaveChangesAsync();
        }
        public bool PaymentDetailExists(int id) {
            return _context.PaymentDetails.Any(e => e.PMId == id);
        }
    }
}
