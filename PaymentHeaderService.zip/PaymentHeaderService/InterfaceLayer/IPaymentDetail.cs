﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ModelLayer;

namespace InterfaceLayer
{
    public interface IPaymentDetail
    {
        Task<IEnumerable<PaymentDetailModel>> GetPaymentDetails();
        Task<object> SaveChangesAsync(PaymentDetailModel paymentDetail);
        Task<PaymentDetailModel> GetPaymentDetailByID(int id);
        Task<Int32> PostPaymentDetail(PaymentDetailModel paymentDetail);
        Task<object> Remove(PaymentDetailModel paymentDetail);
        bool PaymentDetailExists(int id);

    }
}
    