﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InterfaceLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModelLayer;

namespace PaymentHeaderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentDetailController : ControllerBase
    {
        private IPaymentDetail _IPaymentDetail;

        public PaymentDetailController(IPaymentDetail objIPaymentDetail)
        {
            _IPaymentDetail = objIPaymentDetail;
        }

        [HttpGet]
        // GET: api/PaymentDetail
        public async Task<IEnumerable<PaymentDetailModel>> GetPaymentDetails()
        {
            return await _IPaymentDetail.GetPaymentDetails();
        }

        // PUT: api/PaymentDetail/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPaymentDetail(int id, PaymentDetailModel paymentDetail)
        {
            if (id != paymentDetail.PMId)
            {
                return BadRequest();
            }

            try
            {
                await _IPaymentDetail.SaveChangesAsync(paymentDetail);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_IPaymentDetail.PaymentDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // GET: api/PaymentDetail/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PaymentDetailModel>> GetPaymentDetail(int id)
        {
            var paymentDetail = await _IPaymentDetail.GetPaymentDetailByID(id);

            if (paymentDetail == null)
            {
                return NotFound();
            }

            return paymentDetail;
        }

        // POST: api/PaymentDetail
        [HttpPost]
        public async Task<ActionResult<PaymentDetailModel>> PostPaymentDetail(PaymentDetailModel paymentDetail)
        {
            await _IPaymentDetail.PostPaymentDetail(paymentDetail);

            return CreatedAtAction("GetPaymentDetail", new { id = paymentDetail.PMId }, paymentDetail);
        }

        // DELETE: api/PaymentDetail/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<PaymentDetailModel>> DeletePaymentDetail(int id)
        {
            var paymentDetail = await _IPaymentDetail.GetPaymentDetailByID(id);
            if (paymentDetail == null)
            {
                return NotFound();
            }

            await _IPaymentDetail.Remove(paymentDetail);
            return paymentDetail;
        }

        [Route("TestThis")]
        //http://localhost:49602/api/PaymentDetail/TestThis?id=5&name=mangesh
        public void Test(int id, string name)
        {

        }

        [Route("TestThis1")]
        //http://localhost:49602/api/PaymentDetail/TestThis1
        //body => raw => json
        // FromBody will take the request from the form body ["Complex" type]
        // FromURI [Default] will take the request from the URI.["Simple" type]
        public void Test1([FromBody]int id)
        {

        }
    }
}
